<?php
require_once 'header.php';
require_once 'classes/Database.php';

$token = $_GET['token'] ?? '';
$db = new Database();

$stmt = $db->prepare("SELECT email FROM parent_tokens WHERE token = ? AND expires_at > NOW()");
$stmt->execute([$token]);
$row = $stmt->fetch();

if (!$row) {
    echo "<div class='container'><p>Invalid or expired token.</p></div>";
    exit;
}

$email = $row['email'];
$children = $db->prepare("SELECT * FROM kjihc_members WHERE guardian_email = ?");
$children->execute([$email]);
$children = $children->fetchAll();
?>
<div class="container">
  <h2>Parent Dashboard</h2>
  <ul class="nav nav-tabs" role="tablist">
    <?php foreach ($children as $i => $child): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo $i==0?'active':''; ?>" data-toggle="tab" href="#child<?php echo $i; ?>">
          <?php echo htmlspecialchars($child['player_name']); ?>
        </a>
      </li>
    <?php endforeach; ?>
  </ul>

  <div class="tab-content">
    <?php foreach ($children as $i => $child): ?>
    <div class="tab-pane container <?php echo $i==0?'active show':''; ?>" id="child<?php echo $i; ?>">
      <form method="post" action="update_parent_child.php">
        <input type="hidden" name="id" value="<?php echo $child['id']; ?>">
        <div class="form-group">
          <label>Guardian Contact Number</label>
          <input type="text" name="guardian_phone" class="form-control" value="<?php echo htmlspecialchars($child['guardian_phone']); ?>">
        </div>
        <div class="form-group">
          <label>Emergency Contact</label>
          <input type="text" name="emergency_contact" class="form-control" value="<?php echo htmlspecialchars($child['emergency_contact']); ?>">
        </div>
        <div class="form-group">
          <label>Medical Info</label>
          <textarea name="medical_info" class="form-control"><?php echo htmlspecialchars($child['medical_info']); ?></textarea>
        </div>
        <div class="form-check">
          <input type="checkbox" name="policy_confirm" class="form-check-input" required>
          <label class="form-check-label">I confirm I have reviewed and accept club policies</label>
        </div>
        <button type="submit" class="btn btn-success">Save Changes</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
