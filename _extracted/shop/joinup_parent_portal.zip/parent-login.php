<?php
require_once 'header.php';
?>
<div class="container">
  <h2>Parent Portal Login</h2>
  <p>Enter your email to receive a secure login link.</p>
  <form method="post" action="send_parent_link.php">
    <div class="form-group">
      <label>Email Address</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Send Login Link</button>
  </form>
</div>
