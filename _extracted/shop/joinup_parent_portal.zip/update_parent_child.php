<?php
require_once 'classes/Database.php';
$db = new Database();

if (!empty($_POST['id'])) {
    $stmt = $db->prepare("UPDATE kjihc_members SET guardian_phone=?, emergency_contact=?, medical_info=?, guardian_policy_confirmed=NOW() WHERE id=?");
    $stmt->execute([
        $_POST['guardian_phone'],
        $_POST['emergency_contact'],
        $_POST['medical_info'],
        $_POST['id']
    ]);
    echo "<div class='container'><p>Details updated successfully. <a href='javascript:history.back()'>Go Back</a></p></div>";
}
?>
