<?php
session_start();
class StaffController {
	public $name;
	private $mysqli;

function __construct($name) {
	$this->name=$name;
	$this->mysqli = new mysqli("localhost", "join_xv446", "o3De@460p", "join_xv445");
}
function get_name(){
	return $this->name;
}
public function welcomeGreeting(){

	if($_SESSION['staff_email']=="microsoft"){
		
		echo 'Welcome <strong>'.$_SESSION['user']['name'].'</strong>';
	} else {
			echo 'Welcome <strong>'.$_SESSION['staff_email'].'</strong>';

	}
	
}
public function esc($input){
	return mysqli_real_escape_string($input);
}
public function listMembers(){
?>
    <style>
        .expand-row {
            cursor: pointer;
        }
        .medical-info {
            display: none;
        }
    </style>
<div class="container mt-4 table-responsive">
    <div class="card">
        <div class="card-header">
            <h2><i class="bi bi-people-fill"></i> Player Management</h2>
        </div>
		
        <div class="card-body">
			<p class="text-left"><?php $this->welcomeGreeting(); ?></p>
			<p class="text-left">Use this panel to check player information and to reassign age groups, fees or to call the contact number</p>
            <div class="mb-3">
<div class="row">
    <div class="col-12">
        <div class="btn-group btn-group-sm flex-wrap" role="group" aria-label="Age Group Filters">
            <button type="button" class="btn filter-age" data-age="" style="background-color: #f0e6ef; color: #333; border: 1px solid #ddd;">All</button>
            <button type="button" class="btn filter-age" data-age="novice" style="background-color: #e6f0e6; color: #333; border: 1px solid #ddd;">Novice (Skate Club)</button>
            <button type="button" class="btn filter-age" data-age="beginner" style="background-color: #e6eef0; color: #333; border: 1px solid #ddd;">LTP</button>
            <button type="button" class="btn filter-age" data-age="u10" style="background-color: #f0e6e6; color: #333; border: 1px solid #ddd;">U10</button>
            <button type="button" class="btn filter-age" data-age="u12" style="background-color: #f0f0e6; color: #333; border: 1px solid #ddd;">U12</button>
            <button type="button" class="btn filter-age" data-age="u14" style="background-color: #e6f0f0; color: #333; border: 1px solid #ddd;">U14</button>
            <button type="button" class="btn filter-age" data-age="u16" style="background-color: #efe6f0; color: #333; border: 1px solid #ddd;">U16</button>
            <button type="button" class="btn filter-age" data-age="u19" style="background-color: #f0efe6; color: #333; border: 1px solid #ddd;">U19</button>
        </div>
    </div>
</div>
            </div>

            <table id="playerTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Age Group</th>
                        <th>Parent</th>
                        <th>Contact Tel</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
}
public function docs(){
?>
<div class="container mt-4 table-responsive">
    <div class="card">
        <div class="card-header">
            <h2><i class="bi bi-file-earmark-richtext"></i> Useful Documents</h2>
        </div>

        <div class="card-body">
            <p class="text-left"><?php $this->welcomeGreeting(); ?></p>
            <p class="text-left">Use this panel to view or download useful documents.</p>

            <div class="mb-3">
                <div class="row">
                    </div>
            </div>

            <div class="mt-4">
                <h3>Document Downloads</h3>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Document Name</th>
                            <th>Description</th>
                            <th>Download</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>SIHA Registration Form</td>
                            <td>Form for new player registration.</td>
                            <td><a href="#" class="btn btn-primary btn-sm" target="_blank">Download</a></td>
                        </tr>
                        <tr>
                            <td>Code of Conduct</td>
                            <td>Document detailing club rules and regulations.</td>
                            <td><a href="../../resources/KJIHCCOC.docx" class="btn btn-primary btn-sm" target="_blank">Download</a></td>
                        </tr>
                        <tr>
                            <td>Technical Pack</td>
                            <td>The club technical pack.</td>
                            <td><a href="../../resources/techpack.pdf" class="btn btn-primary btn-sm" target="_blank">Download</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </div>
    </div>
</div>
<?php
 }
public function pages(){
switch($_GET['page']){
	default:
		$this->listMembers();
		break;
	case "documents":
		$this->docs();
		break;
}
}
	
}

?>