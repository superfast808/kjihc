<?php
require_once 'vendor/autoload.php';
require_once 'classes/Database.php'; // adjust based on existing DB class

use PHPMailer\PHPMailer\PHPMailer;

if (!empty($_POST['email'])) {
    $email = trim($_POST['email']);
    $db = new Database();

    // Check if email exists in members
    $stmt = $db->prepare("SELECT COUNT(*) as c FROM kjihc_members WHERE guardian_email = ?");
    $stmt->execute([$email]);
    $count = $stmt->fetch()['c'];

    if ($count > 0) {
        $token = bin2hex(random_bytes(16));
        $expires = date('Y-m-d H:i:s', strtotime('+10 minutes'));

        $stmt = $db->prepare("INSERT INTO parent_tokens (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$email, $token, $expires]);

        $link = "https://" . $_SERVER['HTTP_HOST'] . "/parent-dashboard.php?token=" . $token;

        $mail = new PHPMailer(true);
        $mail->setFrom('no-reply@" . $_SERVER['HTTP_HOST'] . "', 'Parent Portal');
        $mail->addAddress($email);
        $mail->Subject = 'Your Parent Portal Login Link';
        $mail->Body = "Click this secure link to view your child details (valid 10 minutes): \n\n" . $link;
        $mail->send();

        echo "<div class='container'><p>Login link sent to your email.</p></div>";
    } else {
        echo "<div class='container'><p>Email not found in our records.</p></div>";
    }
}
?>
